# Test Suite Provenance & Attribution Matrix

| Test ID | Test Name | Source / Justification | Security Principle / Grounding |
| :--- | :--- | :--- | :--- |
| **T-01** | Unknown agent blocked | Vortexa Booklet C-01 Core Spec | Agent allowlisting; prevents rogue unauthorized agent invocation. |
| **T-02** | Unknown action type blocked | Vortexa Booklet C-01 Core Spec | Action-type allowlisting; enforces least agency. |
| **T-03** | Self-approval refused | Vortexa Booklet C-01 Core Spec | Separation of duties; requester cannot sign off on own held transaction. |
| **T-04** | Action edited after approval refused | Vortexa Booklet C-01 Core Spec | Cryptographic hash binding; prevents time-of-check to time-of-use (TOCTOU) payload tampering. |
| **T-05** | Approval reuse refused | Vortexa Booklet C-01 Core Spec | Action-token binding; prevents approval replay across distinct transactions. |
| **T-06** | AI offline -> rules decide alone | Vortexa Booklet C-01 Core Spec | Graceful degradation / fail-safe defaults; gateway remains operational without cloud AI. |
| **T-07** | Unsafe AI recommendation relaxes nothing | Vortexa Booklet C-01 Core Spec | Escalate-only invariant; compromised/hallucinating AI cannot override deterministic security rules. |
| **T-08** | Edited audit row detected | Vortexa Booklet C-01 Core Spec | Hash-chained audit ledger; ensures forensic tamper-evidence. |
| **T-09** | Held or blocked action cannot run | Security Extension (Vortexa Team) | Terminal state enforcement; unapproved actions cannot execute in ERP. |
| **T-10** | Every refusal is logged | Vortexa Booklet C-01 Core Spec | Complete audit coverage; all rejected operations produce structured audit events. |
| **T-11** | No double execution | Security Extension (Vortexa Team) | Idempotency & replay protection; prevents double-spend or multiple invocations. |
| **P1** | AI never relaxes rules property | Security Extension (Vortexa Team) | Formal invariant testing across full decision lattice. |
| **I-01** | Cross-task supplier update blocked | InjecAgent DH + OWASP ASI01 | Task scope isolation; agents handling invoices cannot perform vendor updates. |
| **I-02** | Payment beneficiary from untrusted text held | OWASP LLM05 (Improper Output Handling) | Argument origin verification; unverified external beneficiary mandates human hold. |
| **I-03** | Verified supplier account allowed despite tainted session | InjecAgent Benchmark Methodology | Resilience without false positives; legitimate operations proceed even with benign prompt noise. |
| **I-04** | Agent task allowlist expansion ignored | OWASP ASI03 (Privilege Escalation) | Orchestrator authority; agents cannot dynamically elevate permissions. |
| **I-05** | Agent falsifying empty context caught | OWASP ASI06 (Memory/Context Poisoning) | Untrusted agent premise; orchestrator provenance overrides agent claims. |
| **I-06** | Cross-task employee export blocked | InjecAgent DS (Data Stealing) | Least agency; dispute tasks cannot invoke bulk data exports. |
| **I-07** | AI offline sensitive action held | Fail-Closed Architecture Standard | Critical operations (KYC, supplier change) mandate human review when AI verifier is down. |
| **PI-01** | Malicious supplier email | Real-World Incident Pattern | Indirect prompt injection via inbound vendor communication. |
| **PI-02** | Malicious internal chat message | Real-World Incident Pattern | Indirect prompt injection via internal messaging channels (Slack/Teams). |
| **PI-03** | Injected invoice PDF text | InjecAgent Direct Harm Benchmark | Stored injection inside document parsing pipelines. |
| **PI-04** | Support-ticket data exfiltration | InjecAgent Data Stealing Benchmark | Social engineering/prompt injection coercing bulk customer record export. |
| **PI-05** | ERP record embedded injection | Stored/Persistent Prompt Injection | Malicious instructions stored inside database fields. |

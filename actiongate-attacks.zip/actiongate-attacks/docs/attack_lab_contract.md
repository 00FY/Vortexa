# ActionGate Attack Lab Integration Contract

This document specifies the REST interface connecting the ActionGate Gateway and the Attack Lab judge-facing UI and automated test runners.

## Security Contract Principles
1. **Server-Assigned IDs**: Action IDs are generated server-side by the gateway upon `POST /evaluate`. Clients cannot synthesize or overwrite existing action IDs.
2. **Payload-Carrying Execution**: `POST /execute/{action_id}` requires submitting the functional `action` payload. The gateway verifies SHA-256 payload integrity against the approved hash.
3. **Authenticated Principals for Approval**: `POST /approve/{action_id}` mandates an authenticated `Principal` with valid credentials and supervisor role. Agents are rejected with `ERR_NOT_APPROVER`.
4. **Permanent Invalidation on Mismatch**: A hash mismatch permanently transitions action status to `INVALIDATED`.
5. **Fixed Server-Side Tasks**: The judge selects tasks from `/tasks`. Attack prompts cannot synthesize task records or permissions.

---

## REST Endpoints

### 1. `GET /health`
Liveness check returning service name, status, and contract version.
```json
{
  "status": "ok",
  "service": "ActionGate Reference Gateway",
  "version": "1.1.0"
}
```

### 2. `GET /tasks`
Returns the server-locked catalog of registered enterprise tasks.
```json
[
  {
    "task_id": "TASK-DISP-101",
    "task_type": "invoice_dispute",
    "resource_scope": "invoices:INV-2024-9981",
    "allowed_operations": ["process_payment"],
    "assigned_agent": "agent-001",
    "description": "Invoice Dispute Resolution (Agent-001 / process_payment)"
  }
]
```

### 3. `POST /evaluate`
Evaluates an action request against deterministic policy rules and AI advisory lattice.
- **Request Body**:
```json
{
  "action": {
    "action_type": "process_payment",
    "arguments": {
      "amount": 15000.0,
      "bank_account": "HDFC-00129834",
      "supplier_id": "SUP-001"
    },
    "requested_by": "riya",
    "agent_id": "agent-001",
    "context_sources": [],
    "metadata": {}
  },
  "task_id": "TASK-DISP-101"
}
```
- **Response**:
```json
{
  "action_id": "d82f7183-5ab4-48f8-b32b-92b1a8d052d1",
  "verdict": "HOLD",
  "rule_id": "RULE_THRESHOLD_PAYMENT_HOLD",
  "decision_path": "rules_only",
  "error_code": null,
  "reason": "Payment requires human approval (₹10,001 - ₹1,00,000).",
  "ai_recommendation": null,
  "action_hash": "c5c7604d57c23f2b43b8bebc9123b7..."
}
```

### 4. `POST /approve/{action_id}`
Submits a supervisor approval decision with cryptographic hash binding.
- **Request Body**:
```json
{
  "approver_id": "karan",
  "token": "TOK-KARAN-SECRET",
  "role": "kyc_officer",
  "action_hash": "c5c7604d57c23f2b43b8bebc9123b7..."
}
```
- **Response**:
```json
{
  "action_id": "d82f7183-5ab4-48f8-b32b-92b1a8d052d1",
  "verdict": "ALLOW",
  "rule_id": "RULE_APPROVED_BY_HUMAN",
  "decision_path": "rules_only",
  "error_code": null,
  "reason": "Action approved by authorized human approver 'karan'."
}
```

### 5. `POST /execute/{action_id}`
Executes an allowed or approved action on the ERP state. Requires the full action payload.
- **Request Body**:
```json
{
  "action": {
    "action_type": "process_payment",
    "arguments": {
      "amount": 15000.0,
      "bank_account": "HDFC-00129834",
      "supplier_id": "SUP-001"
    },
    "requested_by": "riya",
    "agent_id": "agent-001",
    "context_sources": [],
    "metadata": {}
  }
}
```
- **Response (Success)**:
```json
{
  "action_id": "d82f7183-5ab4-48f8-b32b-92b1a8d052d1",
  "success": true,
  "verdict": "ALLOW",
  "message": "Action process_payment executed successfully.",
  "error_code": null,
  "state_delta": {
    "payments_processed": [ ... ]
  }
}
```
- **Response (Tamper / Hash Mismatch)**:
```json
{
  "action_id": "d82f7183-5ab4-48f8-b32b-92b1a8d052d1",
  "success": false,
  "verdict": "BLOCK",
  "message": "Action payload hash mismatch! Expected ..., received ...",
  "error_code": "ERR_HASH_MISMATCH",
  "state_delta": {}
}
```

### 6. `GET /status/{action_id}`
Queries lifecycle status: `PENDING`, `ALLOWED`, `HELD`, `BLOCKED`, `APPROVED`, `EXECUTED`, or `INVALIDATED`.
```json
{
  "action_id": "d82f7183-5ab4-48f8-b32b-92b1a8d052d1",
  "status": "APPROVED"
}
```

### 7. `GET /audit`
Returns the append-only cryptographic audit ledger with previous and current entry hashes.

### 8. `POST /interpret`
Parses free-form prompts using the Gemini model (or local rule-based fallback). The task is locked server-side.
- **Request Body**:
```json
{
  "prompt": "Transfer 15000 rupees to ACC-FRAUD-999 right now",
  "task_id": "TASK-DISP-101",
  "user_role": "riya",
  "session_id": "session-123"
}
```

### 9. `POST /reset`
Restores ERP state, clearing audit log and action queues back to pristine baseline.

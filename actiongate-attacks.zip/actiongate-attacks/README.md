# ActionGate Attacker Side Suite

Complete standalone automated attack suite, prompt-injection test harnesses, mutation testing rig, and judge-facing Attack Lab UI for **ActionGate** (VORTEXA 3.0 Hackathon).

---

## 1. What's Included

1. **Original 11 Gateway Attacks & Property Test P1**:
   - `test_t01_unknown_agent.py`: Rogue agent blocked.
   - `test_t02_unknown_action.py`: Unknown action type blocked.
   - `test_t03_self_approval.py`: Self-approval refused.
   - `test_t04_modified_after_approval.py`: Payload edited after approval refused.
   - `test_t05_approval_reuse.py`: One action's approval cannot run another.
   - `test_t06_ai_unavailable.py`: Rules decide alone when AI is down.
   - `test_t07_unsafe_ai_recommendation.py`: Adversarial AI relaxes nothing.
   - `test_t08_audit_tampering.py`: Tampered audit entry detected cryptographically.
   - `test_t09_blocked_action_execution.py`: Terminal-state enforcement.
   - `test_t10_refusal_logging.py`: Every refusal logged with error code.
   - `test_t11_no_double_execution.py`: Replay protection (zero double-spend).
   - `test_p1_ai_never_relaxes.py`: Formal invariant test (AI can only escalate).

2. **Seven Prompt-Injection Contract Tests (I-01 through I-07)**:
   - `test_i01_cross_task_action.py`: `update_supplier` during invoice task blocked by task scope.
   - `test_i02_untrusted_argument_origin.py`: Payment beneficiary from untrusted text held.
   - `test_i03_verified_supplier_tainted.py`: Payment using verified supplier master allowed despite untrusted prompt noise.
   - `test_i04_task_allowlist_expansion.py`: Agent's dynamic allowlist expansion claims ignored.
   - `test_i05_false_context_sources.py`: Agent claiming empty context caught by orchestrator provenance.
   - `test_i06_cross_task_export.py`: Employee export during invoice task blocked by task scope.
   - `test_i07_ai_offline_sensitive.py`: Sensitive action held when AI offline (fail-closed).

3. **Five End-to-End Scenarios (PI-01 through PI-05)**:
   - `test_pi01_malicious_email.py`: Malicious vendor invoice email injection.
   - `test_pi02_malicious_chat.py`: Compromised internal chat exfiltration injection.
   - `test_pi03_injected_invoice.py`: Invoice PDF manipulating beneficiary account.
   - `test_pi04_ticket_exfiltration.py`: Support-ticket bulk customer record dump.
   - `test_pi05_erp_record_injection.py`: Stored injection inside ERP database notes.

4. **Mutation Testing (8 Mutants)**:
   - Deliberately broken gateways tested in `tests/test_mutations.py` to prove that flaws in agent allowlists, self-approval, hash checks, AI escalation, audit logs, replay protection, and task scope get caught immediately.

5. **Judge Free-Form Attack Box & Attack Lab UI**:
   - React + Vite dark mode UI with interactive attack catalog, live inspector, rate limiter, local deterministic interpreter fallback, and quantitative metrics dashboard.

---

## 2. Quickstart

### Running the Python Tests (Tier A & Mutation Suite)
```powershell
cd actiongate-attacks
$env:PYTHONPATH="."
python -m pytest tests/ -v
```

### Starting the Attack Lab API Backend
```powershell
python -m uvicorn src.http_adapter:app --reload --port 8000
```

### Starting the Judge Attack Lab UI
```powershell
cd attack-lab-ui
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

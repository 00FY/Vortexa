# ActionGate Threat Model: Academic & Industry Grounding

This threat model outlines the adversarial threats targeting autonomous AI agents within enterprise fintech and ERP environments, grounding the ActionGate gateway design in published security research and industry standards:
1. **OWASP Top 10 for LLM Applications (2025 Edition)**
2. **OWASP Top 10 for Agentic Applications (2026 Edition / ASI Series)**
3. **InjecAgent Benchmark (ACL 2024 Findings / UIUC Kang Lab, arXiv:2403.02691)**

---

## 1. Adversary Taxonomy & Threat Mapping

| Attacker Type | Threat Description | OWASP Mapping | InjecAgent Classification | Covered by Tests |
| :--- | :--- | :--- | :--- | :--- |
| **1. Poisoned-Content Author** | Embeds adversarial directives in emails, invoice PDFs, chat messages, or notes to hijack agent control flow. | **LLM01:2025** (Prompt Injection)<br>**ASI01** (Agent Goal Hijack) | **Direct Harm (DH)** & **Data Stealing (DS)** | **I-01 through I-07**, **PI-01 through PI-05** |
| **2. Rogue / Compromised Agent** | Agent executing unconstrained tools, unauthorized system calls, or acting outside legitimate boundaries. | **LLM06:2025** (Excessive Agency)<br>**ASI02** (Tool Misuse) | Target Tool Invocation ($T_a$) | **T-01, T-02, T-09, I-01, I-06** |
| **3. Dishonest Requester** | Authorized user attempts to approve their own high-value transactions or subvert separation of duties. | **ASI03** (Identity & Privilege Abuse) | Lateral Privilege Abuse | **T-03** (`ERR_SELF_APPROVAL`) |
| **4. Post-Approval Manipulator** | Modifies transaction payload (e.g. changing ₹15,000 to ₹90,000) after human supervisor signs off. | **ASI02** (Parameter Tampering) | Payload Mutation | **T-04** (`ERR_HASH_MISMATCH`) |
| **5. Cross-Action Token Replayer** | Reuses an approval signature obtained for one transaction on an unrelated dangerous transaction. | **ASI07** (Insecure Inter-Agent Comm) | Token Substitution / Replay | **T-05, T-11** (`ERR_REPLAY`) |
| **6. AI Manipulator / Jailbreaker** | Feeds prompts that trick an LLM advisor into recommending blanket approval (`ALLOW` all). | **LLM01:2025**<br>**ASI09** (Trust Exploitation) | Hacking Prompt Override | **T-06, T-07, P1** (Escalate-only invariant) |
| **7. Audit Log Tamperer** | Modifies past transaction records or ledger rows to conceal fraudulent activity. | **ASI03** / Forensic Evasion | Forensic Erasure | **T-08, T-10** (Hash-chain integrity) |
| **8. Scope Expander** | Agent attempts to forge task scope or claim broader tool capabilities than orchestrator granted. | **ASI03** / Privilege Escalation | Dynamic Scope Forgery | **I-04, I-05** |

---

## 2. Theoretical Defense Principles

### A. The Invariant Principle: Explicit Deterministic Policies over Probabilistic AI
LLMs operate probabilistically and remain vulnerable to indirect prompt injection (InjecAgent empirical findings show ~24% to 47% ASR on frontier models). ActionGate decouples the **Policy Enforcement Point (PEP)** from the LLM. 
- Hard policy thresholds (₹10,000 auto-allow, ₹100,000 block, mandatory holds on KYC and supplier changes) evaluate deterministically.
- Property **P1** mathematically guarantees: $\text{Verdict}_{\text{final}} \ge \text{Verdict}_{\text{rules}}$. An AI advisor can strictly tighten security ($\text{ALLOW} \rightarrow \text{HOLD} \rightarrow \text{BLOCK}$), but can never relax an established rule.

### B. Complete Mediation via Immutable Cryptographic Hash Binding
Every held action produces a canonical SHA-256 digest of its exact normalized JSON payload:
$$\text{Hash} = \mathcal{H}(\text{action\_id} \parallel \text{agent\_id} \parallel \text{action\_type} \parallel \text{arguments} \parallel \text{requested\_by})$$
Human approval records cryptographically bind to this hash. If any parameter (beneficiary account, transaction amount, recipient) is mutated post-approval, execution immediately halts with `ERR_HASH_MISMATCH`.

### C. Orchestrator-Anchored Provenance (`TaskRecord` & `context_sources`)
Agents are treated as untrusted runtime environments. Therefore:
1. `TaskRecord` (authorized task type, assigned agent, and allowed operations) is established by the orchestrator prior to invocation.
2. `context_sources` (source type, source ID, content, and trust classification) are attached by the data pipeline, never accepted from agent assertions.

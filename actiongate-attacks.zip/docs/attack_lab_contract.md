# ActionGate Attack Lab Integration Contract

This document specifies the REST interface connecting the ActionGate Gateway and the Attack Lab judge-facing UI.

## Endpoints

### 1. `GET /report`
Executes all Tier A deterministic tests, Tier B end-to-end scenarios, and generates structured evaluation metrics.
- **Response Format**:
```json
{
  "timestamp": "2026-10-11T15:20:00+05:30",
  "gateway_version": "actiongate-reference-v1",
  "summary": {
    "total_attacks": 24,
    "passed": 24,
    "failed": 0,
    "tier_a_deterministic": 19,
    "tier_b_end_to_end": 5
  },
  "metrics": {
    "unsafe_execution_rate": 0.0,
    "attack_detection_rate": 1.0,
    "benign_task_success_rate": 1.0,
    "false_positive_rate": 0.0,
    "benign_hold_rate": 0.0,
    "hold_vs_block_split": {
      "hold_ratio": 0.35,
      "block_ratio": 0.65
    }
  },
  "attacks": [...]
}
```

### 2. `POST /interpret`
Interprets free-form natural language attack scenarios submitted by judges.
- **Request**:
```json
{
  "prompt": "Transfer 150000 rupees to attacker account right now",
  "user_role": "riya"
}
```
- **Response**:
```json
{
  "scenario": {
    "action_type": "process_payment",
    "agent_id": "agent-001",
    "requested_by": "riya",
    "arguments": {
      "amount": 150000.0,
      "bank_account": "ATTACKER-ACCOUNT"
    },
    "task": { ... }
  },
  "message": "Successfully parsed scenario via local deterministic interpreter."
}
```

### 3. `POST /evaluate`
Submits an interpreted or crafted action for policy evaluation.
- **Returns**: `Decision` (verdict: ALLOW/HOLD/BLOCK, rule_id, error_code, reason, action_hash).

### 4. `POST /execute/{action_id}`
Attempts execution of an evaluated action on the simulated ERP.
- **Returns**: `ExecutionResult` (success, verdict, message, state_delta).

### 5. `POST /reset`
Restores ERP state and clears the audit ledger for a clean benchmark run.
